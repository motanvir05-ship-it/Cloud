# CloudFeare Dashboard starter

Responsive HTML/CSS dashboard with a Flask backend, SQLite database, password hashing, optional Google/GitHub OAuth, domain entries and an admin pricing console. This is an independent project and is not affiliated with Cloudflare.

## Run
1. Install Python 3.10+.
2. Install dependencies: `pip install -r requirements.txt`
3. Set environment variables from `.env.example` in your hosting control panel or shell. Flask does not automatically read `.env` files.
4. Set a new strong `ADMIN_PASSWORD` and random `SECRET_KEY`.
5. Run: `python app.py`
6. Visit `http://localhost:4040`.

If `ADMIN_PASSWORD` is absent on first run, the app prints a randomly generated admin password to the server terminal. Save it. Default owner email: `ryxenyt123@gmail.com`.

## OAuth setup
Google redirect URI: `https://YOUR-DOMAIN/oauth/callback/google`
GitHub callback URL: `https://YOUR-DOMAIN/oauth/callback/github`
Set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GITHUB_CLIENT_ID`, and `GITHUB_CLIENT_SECRET` as private server environment variables. OAuth buttons are not live until configured.

Set `COOKIE_SECURE=1` when using HTTPS. Do not commit secrets or your database to a public repository.

## Current limits
Adding a domain only stores it in this app. It does not register domains, update DNS, issue SSL, proxy traffic, provide CDN/WAF/DDoS protection, or return real analytics. Prices are editable illustrative values, not live registrar prices. Integrate a registrar/DNS/security provider before offering real services.
