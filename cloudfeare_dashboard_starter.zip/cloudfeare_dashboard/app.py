import os, re, sqlite3, secrets
from functools import wraps
from flask import Flask, g, request, redirect, url_for, session, render_template, flash
from werkzeug.security import generate_password_hash, check_password_hash
from authlib.integrations.flask_client import OAuth

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config['DATABASE'] = os.environ.get('DATABASE_PATH', 'cloudfeare.db')
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('COOKIE_SECURE', '0') == '1'

def connect():
    if 'db' not in g:
        g.db = sqlite3.connect(app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    db = g.pop('db', None)
    if db is not None: db.close()

def init_db():
    con = sqlite3.connect(app.config['DATABASE'])
    con.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT, provider TEXT DEFAULT 'local', is_admin INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS domains(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name TEXT NOT NULL, status TEXT DEFAULT 'Pending setup', created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id,name));
    CREATE TABLE IF NOT EXISTS prices(tld TEXT PRIMARY KEY, registration REAL NOT NULL, renewal REAL NOT NULL, currency TEXT DEFAULT 'USD');
    ''')
    email = os.environ.get('ADMIN_EMAIL', 'ryxenyt123@gmail.com').lower().strip()
    password = os.environ.get('ADMIN_PASSWORD')
    row = con.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()
    if not row:
        if not password:
            password = secrets.token_urlsafe(16)
            print('\nFIRST START ADMIN PASSWORD (save this securely):', password, '\n')
        con.execute('INSERT INTO users(email,password_hash,is_admin) VALUES(?,?,1)', (email, generate_password_hash(password)))
    for tld, reg, ren in [('.com',12.99,14.99),('.in',8.99,9.99),('.net',13.99,15.99),('.org',11.99,13.99)]:
        con.execute('INSERT OR IGNORE INTO prices(tld,registration,renewal) VALUES(?,?,?)', (tld,reg,ren))
    con.commit(); con.close()

def login_required(fn):
    @wraps(fn)
    def inner(*a, **kw):
        if not session.get('user_id'): return redirect(url_for('login'))
        return fn(*a, **kw)
    return inner

def admin_required(fn):
    @wraps(fn)
    def inner(*a, **kw):
        if not session.get('user_id'): return redirect(url_for('login'))
        if not session.get('is_admin'):
            flash('Admin access required.', 'error'); return redirect(url_for('dashboard'))
        return fn(*a, **kw)
    return inner

oauth = OAuth(app)
if os.environ.get('GOOGLE_CLIENT_ID') and os.environ.get('GOOGLE_CLIENT_SECRET'):
    oauth.register(name='google', client_id=os.environ['GOOGLE_CLIENT_ID'], client_secret=os.environ['GOOGLE_CLIENT_SECRET'], server_metadata_url='https://accounts.google.com/.well-known/openid-configuration', client_kwargs={'scope':'openid email profile'})
if os.environ.get('GITHUB_CLIENT_ID') and os.environ.get('GITHUB_CLIENT_SECRET'):
    oauth.register(name='github', client_id=os.environ['GITHUB_CLIENT_ID'], client_secret=os.environ['GITHUB_CLIENT_SECRET'], access_token_url='https://github.com/login/oauth/access_token', authorize_url='https://github.com/login/oauth/authorize', api_base_url='https://api.github.com/', client_kwargs={'scope':'user:email'})

def sign_in(email, provider='local'):
    email = email.strip().lower(); db = connect()
    row = db.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
    if not row:
        db.execute('INSERT INTO users(email,provider) VALUES(?,?)', (email,provider)); db.commit()
        row = db.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
    session.clear(); session['user_id'] = row['id']; session['email'] = row['email']; session['is_admin'] = bool(row['is_admin'])

@app.route('/')
def home(): return redirect(url_for('dashboard') if session.get('user_id') else url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email','').strip().lower(); password = request.form.get('password','')
        row = connect().execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
        if row and row['password_hash'] and check_password_hash(row['password_hash'], password):
            session.clear(); session['user_id']=row['id']; session['email']=row['email']; session['is_admin']=bool(row['is_admin'])
            return redirect(url_for('dashboard'))
        flash('Invalid email or password.', 'error')
    return render_template('login.html', google_enabled='google' in oauth._clients, github_enabled='github' in oauth._clients)

@app.route('/oauth/<provider>')
def oauth_login(provider):
    if provider not in ('google','github') or provider not in oauth._clients:
        flash(f'{provider.title()} login is not configured. Add provider credentials to server environment.', 'error'); return redirect(url_for('login'))
    return oauth.create_client(provider).authorize_redirect(url_for('oauth_callback', provider=provider, _external=True))

@app.route('/oauth/callback/<provider>')
def oauth_callback(provider):
    if provider not in oauth._clients: return redirect(url_for('login'))
    client = oauth.create_client(provider); token = client.authorize_access_token(); email = None
    if provider == 'google':
        info = token.get('userinfo') or client.parse_id_token(token)
        email = info.get('email') if info else None
        verified = bool(info and info.get('email_verified'))
    else:
        profile = client.get('user', token=token).json(); email = profile.get('email'); verified = bool(email)
        if not email:
            emails = client.get('user/emails', token=token).json()
            found = next((x for x in emails if x.get('primary') and x.get('verified')), None)
            email = found.get('email') if found else None; verified = bool(found)
    if not email or not verified:
        flash('Provider did not return a verified email address.', 'error'); return redirect(url_for('login'))
    sign_in(email, provider); return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    db = connect(); domains = db.execute('SELECT * FROM domains WHERE user_id=? ORDER BY id DESC',(session['user_id'],)).fetchall()
    domain_count = db.execute('SELECT COUNT(*) n FROM domains').fetchone()['n'] if session.get('is_admin') else len(domains)
    prices = db.execute('SELECT * FROM prices ORDER BY tld').fetchall()
    return render_template('dashboard.html', domains=domains, domain_count=domain_count, prices=prices)

def valid_domain(value):
    value = value.strip().lower().rstrip('.')
    if len(value)>253 or '.' not in value: return None
    if not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}', value): return None
    return value

@app.route('/domains/add', methods=['POST'])
@login_required
def add_domain():
    name = valid_domain(request.form.get('domain',''))
    if not name: flash('Enter a valid domain, such as example.com.', 'error')
    else:
        try:
            connect().execute('INSERT INTO domains(user_id,name) VALUES(?,?)',(session['user_id'],name)); connect().commit()
            flash('Added to dashboard. This does not register the domain or change live DNS.', 'success')
        except sqlite3.IntegrityError: flash('That domain is already in your account.', 'error')
    return redirect(url_for('dashboard'))

@app.route('/domains/<int:domain_id>/delete', methods=['POST'])
@login_required
def delete_domain(domain_id):
    connect().execute('DELETE FROM domains WHERE id=? AND user_id=?',(domain_id,session['user_id'])); connect().commit()
    flash('Domain removed from this dashboard.', 'success'); return redirect(url_for('dashboard'))

@app.route('/admin', methods=['GET','POST'])
@admin_required
def admin():
    db=connect()
    if request.method=='POST':
        tld=request.form.get('tld','').strip().lower()
        try:
            reg=float(request.form.get('registration','')); ren=float(request.form.get('renewal',''))
            if not re.fullmatch(r'\.[a-z0-9-]{2,20}',tld) or reg<0 or ren<0: raise ValueError()
            db.execute('INSERT INTO prices(tld,registration,renewal) VALUES(?,?,?) ON CONFLICT(tld) DO UPDATE SET registration=excluded.registration,renewal=excluded.renewal',(tld,reg,ren)); db.commit(); flash('Price saved.', 'success')
        except ValueError: flash('Enter a TLD like .com and valid non-negative prices.', 'error')
    prices=db.execute('SELECT * FROM prices ORDER BY tld').fetchall()
    users=db.execute('SELECT id,email,provider,is_admin,created_at FROM users ORDER BY id DESC').fetchall()
    domains=db.execute('SELECT domains.*,users.email FROM domains JOIN users ON users.id=domains.user_id ORDER BY domains.id DESC').fetchall()
    return render_template('admin.html',prices=prices,users=users,domains=domains)

@app.route('/logout',methods=['POST'])
def logout(): session.clear(); return redirect(url_for('login'))

if __name__=='__main__':
    init_db(); app.run(host='0.0.0.0',port=int(os.environ.get('PORT','4040')),debug=False)
